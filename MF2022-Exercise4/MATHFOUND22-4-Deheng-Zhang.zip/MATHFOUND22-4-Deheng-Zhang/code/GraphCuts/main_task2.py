from graph_cut_controller import GraphCutController


def main():
    GraphCutController()


if __name__ == '__main__':
    main()
